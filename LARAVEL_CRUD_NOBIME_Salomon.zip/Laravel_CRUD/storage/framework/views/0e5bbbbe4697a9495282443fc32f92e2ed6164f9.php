

<?php $__env->startSection("contenu"); ?>
<div class="my-3 p-3 bg-body rounded shadow-sm">
    <h3 class="border-bottom pb-2 mb-4">Listes des etudiants</h3>
    <div class="mt-4">
        <div class="d-flex justify-content-end mb-4">
        <div>
        <a href="<?php echo e(route('etudiant.create')); ?>" class="btn btn-primary">Ajouter un nouvel Etudiant</a></div>

        </div>
        <?php if(session()->has("successDelete")): ?>
        <div class="alert alert-success">
            <h3><?php echo e(session()->get('successDelete')); ?></h3>
        </div>
        <?php endif; ?>
    <table class="table table-bordered table-hover" >
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Nom</th>
      <th scope="col">Prénom</th>
      <th scope="col">Niveau</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  
      <?php $__currentLoopData = $etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($loop->index + 1); ?></th>
      <td><?php echo e($etudiant->nom); ?></td>
      <td><?php echo e($etudiant->prenom); ?></td>
      <td><?php echo e($etudiant->classe->libelle); ?></td>
      <td>
          <a href="<?php echo e(route('etudiant.edit',['etudiant'=>$etudiant->id])); ?>" class="btn btn-info">Editer</a>
          <a href="#" class="btn btn-danger" onclick="if(confirm('voulez-vous vraiment supprimer cet etudiant?')){document.getElementById('form-<?php echo e($etudiant->id); ?>').submit()}">Supprimer</a>
          <form id="form-<?php echo e($etudiant->id); ?>" action="<?php echo e(route('etudiant.supprimer',['etudiant'=>$etudiant->id])); ?>" method="post" >
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_method" value="delete" >
                  </form>

      </td>
      
    </tr> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
  
</table>
    </div>
    
  </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-first-crud-app\resources\views/etudiant.blade.php ENDPATH**/ ?>