<?php $__env->startSection("contenu"); ?>
<div class="my-3 p-3 bg-body rounded shadow-sm">
    <h3 class="border-bottom pb-2 mb-4">Bienvenue dans notre Application</h3>

  </div>
  <?php $__env->stopSection(); ?>


<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ensa_laravel\resources\views/welcome.blade.php ENDPATH**/ ?>