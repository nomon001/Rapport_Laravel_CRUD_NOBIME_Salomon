

<?php $__env->startSection("contenu"); ?>
<div class="my-3 p-3 bg-body rounded shadow-sm">
    <h3 class="border-bottom pb-2 mb-4">Edition d'un Etudiant</h3>
    <div class="mt-4">
        <?php if(session()->has("success")): ?>
        <div class="alert alert-success">
            <h3><?php echo e(session()->get('success')); ?></h3>
        </div>
        <?php endif; ?>


    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
     <form style="width:65%; " method="post" action="<?php echo e(route('etudiant.update', ['etudiant'=>$etudiant->id])); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="_method" value="put">
     <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Nom de l'étudiant</label>
    <input type="text" class="form-control"  required name="nom" value="<?php echo e($etudiant->nom); ?>">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Prenom de l'étudiant</label>
    <input type="text" class="form-control" name="prenom" value="<?php echo e($etudiant->prenom); ?>">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Classe</label>
    <select class="form-control" name="classe_id" >
         <option value=""></option>
         <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php if($classe->id == $etudiant->classe_id): ?>
            <option value="<?php echo e($classe->id); ?>" selected><?php echo e($classe->libelle); ?></option>
        <?php else: ?>
        <option value="<?php echo e($classe->id); ?>" ><?php echo e($classe->libelle); ?></option>
        <?php endif; ?> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  
  <button type="submit" class="btn btn-primary">Enregistrer</button>
  <a href="<?php echo e(route('etudiant')); ?>" class="btn btn-danger">Annuler</a>
</form>
    
    </div>
    
  </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-first-crud-app\resources\views/editEtudiant.blade.php ENDPATH**/ ?>